from flask import Flask
from flask import request
from flask.ext.jsonpify import jsonify
from flask import render_template
import json

import pandas as pd
import numpy as np
import random
from random import randint
import pickle

# JWT Auth
from flask_jwt import JWT, jwt_required, current_identity
from werkzeug.security import safe_str_cmp


class User(object):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

    def __str__(self):
        return "User(id='%s')" % self.id


users = []
with open("accounts.json") as f:
    accounts = json.load(f);
    users = [User(u["id"], u["name"], u["password"]) for u in accounts["users"]]

name_to_user = {u.username: u for u in users}
id_to_user = {u.id: u for u in users}


def authenticate(username, password):
    user = name_to_user.get(username)
    if user and safe_str_cmp(user.password.encode('utf-8'), password.encode('utf-8')):
        return user

def identity(payload):
    user_id = payload['identity']
    return id_to_user.get(user_id)


app = Flask(__name__)
app.debug = True
app.config['SECRET_KEY'] = 'esdc_aixaudit'

jwt = JWT(app, authenticate, identity)

#LOAD DATA
def init_data():
    risks = pd.read_csv("data/risksbyprogram.csv")
    risks = risks[risks.risk > 0.95].sent.values

    sentence = []
    with open("./data/sentences.pkl","rb") as f:
        sentences = pickle.load(f)

    sentence_sample = np.array(sentences)[np.random.permutation(len(risks))]


    data = np.hstack((risks,sentence_sample)).tolist()
    random.shuffle(data)
    return data

data = init_data()


#ROUTES
@app.route("/")
def index():
    #doing some p
    return render_template('index.html')


@app.route("/check")
@jwt_required()
def check():
    return jsonify({"success":True})

@app.route("/get_sentence",methods=['GET'])
@jwt_required()
def get_sentence():
    if request.method == 'GET':
        index = randint(0,len(data)-1)
        sentence = data[index]

        print(current_identity);

        count = 0
        with open('trained.json','r') as f:
            trained = json.load(f)
            for train in trained:
                if train["user_id"] == current_identity.id: count+=1


        return jsonify({"sentence":sentence,"username":current_identity.username,"count":count})



@app.route("/train",methods=['POST'])
@jwt_required()
def train():

    if request.method == 'POST':
        print("POST METHOD");

        req = request.get_json()


        sentence = req["sentence"]
        is_risk = req["is_risk"]

        if is_risk == None: return jsonify({"success":True})

        filename = 'trained.json'

        try:
            f = open(filename,'r')
            data = json.load(f)
            f.close()

            data.append({"sentence":sentence,"is_risk":is_risk,"user_id":current_identity.id})

            f = open(filename,'w')
            json.dump(data, f)
            f.close()


        except:
            f = open(filename,'w')
            data = [{"sentence":sentence,"is_risk":is_risk}]
            json.dump(data, f)
            f.close()



        return jsonify({"success":True})

if __name__ == "__main__":
    app.run()
